package test.system;

import api.View;
import api.Controller;
import api.Game;
import exc.GameStateException;
import exc.IllegalMoveException;
import impl.GameController;
import impl.GameFactory;
import impl.GameTemplate;
import impl.GameTypes.ConnectFourGame;
import impl.ViewTypes.ConsoleView;
import impl.ViewTypes.GraphicalView;
import javafx.application.Application;
import util.Chip;

@SuppressWarnings("unused")
public class GameTest {
    public static void main(String[] args) throws NumberFormatException, GameStateException, IllegalMoveException {    	
    	GameFactory factory = new GameFactory();
    	//game gets started when created in the factory 
    	factory.createGame(args[0], args[1]);
    }
}
