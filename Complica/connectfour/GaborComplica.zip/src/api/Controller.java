package api;

public interface Controller {
    public void handlePlaceDisk(int row, int col);
}
